// Abi Hesab - Basic Version
void main() => print('Abi Hesab Basic');